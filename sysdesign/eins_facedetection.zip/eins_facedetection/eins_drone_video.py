# source drone/bin/activate 

import cv2 as cv

digi_cap = cv.VideoCapture(2)

digiface_cascade = cv.CascadeClassifier('tools/haarcascade_frontalface_default.xml')
digieye_cascade = cv.CascadeClassifier('tools/haarcascade_eye.xml')

while True:
    ret, frame = digi_cap.read()
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    faces = digiface_cascade.detectMultiScale(gray, 1.3, 5)
    print(len(faces))

    for (x,y,w,h) in faces:
        cv.rectangle(frame, (x,y), (x+h, y+h), (255, 0 , 0), 2)
        eye_gray = gray[y:y+h, x:x+w]
        eye_color = frame[y:y+h, x:x+w]
        eyes = digieye_cascade.detectMultiScale(eye_gray)
        for (ex, ey, ew, eh) in eyes:
            cv.rectangle(eye_color, (ex, ey), (ex+ew, ey+eh), (0,255,0), 2)


    cv.imshow('frame', frame)
    if cv.waitKey(1) & 0xFF == ord('d'):
        break

cv.destroyAllWindows()